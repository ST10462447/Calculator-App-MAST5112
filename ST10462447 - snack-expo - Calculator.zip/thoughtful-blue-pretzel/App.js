import React, { useState } from 'react';
import { StyleSheet, 
         Text, 
         View, 
         TouchableOpacity 
        }from 'react-native';

export default function App() {
  const [input, setInput] = useState('');

  const handlePress = (value) => {
    if (value === '=') {
      try {
        setInput(eval(input).toString());
      } catch (error) {
        setInput('Error');
      }
    } else if (value === 'C') {
      setInput('');
    } else {
      setInput(input + value);
    }
  };

  const Button = ({ onPress, title }) => (
  <TouchableOpacity style={styles.button} onPress={() => onPress(title)}>
    <Text style={styles.buttonText}>{title}</Text>
  </TouchableOpacity>
);

  return (
    <View style={styles.container}>
      <Text style={styles.input}>{input}</Text>
      <View style={styles.buttonRow}>
        <Button 
        title="1" 
        onPress={() => handlePress('1')} 
        />
        <Button 
        title="2"
        onPress={() => handlePress('2')} 
        />
        <Button 
        title="3"  
        onPress={() => handlePress('3')} 
        />
        <Button 
        title="+"
        onPress={() => handlePress('+')}  
        />
      </View>
      <View style={styles.buttonRow}>
        <Button 
        title="4" 
        onPress={() => handlePress('4')}
        />
        <Button 
        title="5"
        onPress={() => handlePress('5')}
        />
        <Button
        title="6" 
        onPress={() => handlePress('6')}
        />
        <Button
        title="-"
        onPress={() => handlePress('-')}
        />
      </View>
      <View style={styles.buttonRow}>
        <Button
        title="7" 
        onPress={() => handlePress('7')}
        />
        <Button 
        title="8" 
        onPress={() => handlePress('8')}
        />
        <Button 
        title="9"
        onPress={() => handlePress('9')}
        />
        <Button
        title="*" 
        onPress={() => handlePress('*')}  />
      </View>
      <View style={styles.buttonRow}>
        <Button
        title="0" 
        onPress={() => handlePress('0')}
        />
        <Button
        title="."  
        onPress={() => handlePress('.')} 
        />
        <Button 
        title="√"
        onPress={() => handlePress('√')}
        />
        <Button
        title="/"
        onPress={() => handlePress('/')}
        />
      </View>
      <View style={styles.buttonRow}>
        <Button 
        title="C"
        onPress={() => handlePress('C')}
        />
        <Button
        title='√'
        onPress={() => handlePress('√')}
        />
        <Button
        title="="
        onPress={() => handlePress('=')}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  input: {
    fontSize: 48,
    marginBottom: 20,
    textAlign: 'right',
    width: '100%',
    padding: 20,
  },
  buttonRow: {
    flexDirection: 'row',
  },
  button: {
    width: 80,
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 5,
    backgroundColor: '#ddd',
    borderRadius: 10,
  },
  buttonText: {
    fontSize: 24,
    color: '#333',
  },
});